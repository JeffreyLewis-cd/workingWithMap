/**
 * Created by Administrator on 2017/6/23.
 */
$(function(){
    var wordsH=$(window).height();
    var wordsToTop=(wordsH-200)/2;
    console.log(wordsH);
    $('.threeDcontent').css({"height":(wordsH-wordsToTop)+"px","padding-top":wordsToTop+"px"});

});