/**
 * Created by Administrator on 2017/5/9.
 */
var userName;
var password;

//设置高度
$(function () {
    $('.loginPage').css('height', $(window).height() - 100);
    $(window).resize(function () {
        $('.loginPage').css('height', $(window).height() - 100);
    });
});//$(function () {

//验证格式
$('.loginUserName, .loginPassword').on('focusout',function () {
    if($(this).val()==''){
        $(this).parent().addClass('formError');
        $(this).parent().next().css('display','block');
        $(this).prev().css('color','red');
    }else {
        $(this).parent().removeClass('formError');
        $(this).parent().next().css('display','none');
        $(this).prev().css('color','#555555');
    }
});

//验证用户名和密码
$('.loginBtn').on('click', function () {
    userName = $('.loginUserName').val();
    password = $('.loginPassword').val();
    $.getJSON('data/loginData.json',function (data) {
        var checkLogin=false;
        for(var key in data.LoginData){
            if (userName == data.LoginData[key].userName & password == data.LoginData[key].password) {
                checkLogin=true;
            }
        }   // for(var key in data.LoginData){
        console.log(checkLogin);
        checkLogin?window.location.href = 'template/homePage.html':$('.loginFail').css('display', 'block');
    });//    $.getJSON('data/loginData.json'

//记住我以后，刷新网页
    if ($("input[type='checkbox']").is(':checked') == true) {
        if (window.localStorage) {
            localStorage.setItem("userName", userName);
            localStorage.setItem("password", password);
        } else {
            Cookie.write("userName", userName);
            Cookie.write("password", password);
        }

    }
});

//隐藏登录失败提示
$('.loginAlerClose').on('click', function () {
    $('.loginFail').css('display', 'none');
});

//设置默认用户名
var defaultUserName = window.localStorage ? localStorage.getItem("userName") : Cookie.read("userName");
var defaultPassword = window.localStorage ? localStorage.getItem("password") : Cookie.read("password");
$('.loginUserName').val(defaultUserName);
$('.loginPassword').val(defaultPassword);







