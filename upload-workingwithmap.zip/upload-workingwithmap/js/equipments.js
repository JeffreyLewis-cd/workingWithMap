/**
 * Created by Administrator on 2017/6/26.
 */
$(function(){
    $('.empty-equipmentInput').on('click',function(){
        $('.equipment-inputVal').val("")
    })
});