/**
 * Created by Administrator on 2017/5/11.
 */
$(function () {
    //页面高度
    $('.hPContent, .hPContentLeftBar, .hPContentLeftBarDetails, .block-container').css('height', $(window).height() - 50);
    if(!window.localStorage){
        alert("浏览器支持localstorage");
        return false;
    }else{
        var storage=window.localStorage;
        storage.blockDetailsH=$(window).height() - 120;
    }

    $(window).resize(function () {
        $('.hPContent, .hPContentLeftBar, .hPContentLeftBarDetails, .block-container,').css('height', $(window).height() - 50);
    });
    // 百度地图初始化
    var map = new BMap.Map("arcgisMapContent");    // 创建Map实例
    map.centerAndZoom(new BMap.Point(105.346, 29.409), 8);  // 初始化地图,设置中心点坐标和地图级别
    map.addControl(new BMap.MapTypeControl());   //添加地图类型控件
    map.setCurrentCity("成都");          // 设置地图显示的城市 此项是必须设置的
    map.enableScrollWheelZoom(true);     //开启鼠标滚轮缩放
    map.disableDoubleClickZoom();

    //添加定位组件
    var geolocationControl = new BMap.GeolocationControl({anchor: BMAP_ANCHOR_BOTTOM_RIGHT});
    geolocationControl.addEventListener("locationSuccess", function (e) {
        // 定位成功事件
        var address = '';
        address += e.addressComponent.province;
        address += e.addressComponent.city;
        address += e.addressComponent.district;
        address += e.addressComponent.street;
        address += e.addressComponent.streetNumber;
        alert("当前定位地址为：" + address);
    });
    geolocationControl.addEventListener("locationError", function (e) {
        // 定位失败事件
        alert(e.message);
    });
    map.addControl(geolocationControl);

    //设置壳牌公司区块边界
    function getBoundaryShell(cityName, iconLocation) {
        var bdary = new BMap.Boundary();
        var name = cityName;
        var iconPoint = iconLocation;
        bdary.get(name, function (rs) {       //获取行政区域
            var cdPoints = rs.boundaries[0].split(';'); //行政区域的点有多少个
            var overlay = [];
            for (var key in cdPoints) {
                var cdPoint = cdPoints[key].split(',');
                overlay.push(new BMap.Point(cdPoint[0], cdPoint[1]))
            }
            var polygon = new BMap.Polygon(overlay, {
                strokeColor: "black",
                strokeWeight: 1,
                strokeOpacity: 1,
                fillColor: "yellow",
                fillOpacity: 0.5
            });  //创建多边形

            //console.log(polygon);
            map.addOverlay(polygon);   //增加多边形
            function redBoundary(){
                polygon.setStrokeWeight(3);
                polygon.setStrokeColor('red');
                polygon.setFillOpacity(0.7);
            }
            function blackBoundary(){
                polygon.setStrokeWeight(1);
                polygon.setStrokeColor('black');
                polygon.setFillOpacity(0.5);
            }

            //鼠标点击，突出边界
            polygon.addEventListener("click", function () {
                redBoundary();
            });
            polygon.addEventListener("dblclick", function () {
                blackBoundary();
            });

            //mouseover左侧列表
            $('.shellChina').on('mouseover', function () {
                redBoundary();
            });
            $('.shellChina').on('mouseout', function () {
                blackBoundary();
            });

            //在区块上面添加标注
            var shellChina_points = iconPoint;

            var shellChina_pt = new BMap.Point(shellChina_points[0], shellChina_points[1]);
            var shellChina_myIcon = new BMap.Icon("../img/shellS02.png", new BMap.Size(24, 26));
            var shellChina_marker = new BMap.Marker(shellChina_pt, {icon: shellChina_myIcon});  // 创建标注
            map.addOverlay(shellChina_marker);              // 将标注添加到地图中
            shellChina_marker.addEventListener("click", function () {
                redBoundary();
            });
            shellChina_marker.addEventListener("dblclick", function () {
                blackBoundary();
            });
        });
    }

    getBoundaryShell('梓潼', [105.176, 31.738]);
    getBoundaryShell('三台',[105.043, 31.079]);
    getBoundaryShell('泸州',[105.538, 28.732]);

    //设置中石油区块边界
    function getBoundaryCNPC(cityName, iconLocation) {
        var bdary = new BMap.Boundary();
        var name = cityName;
        bdary.get(name, function (rs) {       //获取行政区域
            var cdPoints = rs.boundaries[0].split(';'); //行政区域的点有多少个
            var overlay = [];
            for (var key in cdPoints) {
                var cdPoint = cdPoints[key].split(',');
                overlay.push(new BMap.Point(cdPoint[0], cdPoint[1]))
            }
            var polygon = new BMap.Polygon(overlay, {
                strokeColor: "black",
                strokeWeight: 1,
                strokeOpacity: 1,
                fillColor: "darkgreen",
                fillOpacity: 0.5
            });  //创建多边形

            //console.log(polygon);
            map.addOverlay(polygon);   //增加多边形
            function redBoundary(){
                polygon.setStrokeWeight(3);
                polygon.setStrokeColor('red');
                polygon.setFillOpacity(0.7);
            }
            function blackBoundary(){
                polygon.setStrokeWeight(1);
                polygon.setStrokeColor('black');
                polygon.setFillOpacity(0.5);
            }

            //鼠标点击，突出边界
            polygon.addEventListener("click", function () {
                redBoundary();
            });
            polygon.addEventListener("dblclick", function () {
                blackBoundary();
            });

            //mouseover左侧列表
            $('.petroChina').on('mouseover', function () {
                polygon.setStrokeWeight(3);
                polygon.setStrokeColor('red');
                polygon.setFillOpacity(0.7);
            });
            $('.petroChina').on('mouseout', function () {
                polygon.setStrokeWeight(1);
                polygon.setStrokeColor('black');
                polygon.setFillOpacity(0.5);
            });

            //在区块上面添加标注
            var petroChina_points = iconLocation;

            var petroChina_pt = new BMap.Point(petroChina_points[0], petroChina_points[1]);
            var petroChina_myIcon = new BMap.Icon("../img/petroChinaS02.png", new BMap.Size(30, 30));
            var petroChina_marker = new BMap.Marker(petroChina_pt, {icon: petroChina_myIcon});  // 创建标注
            map.addOverlay(petroChina_marker);              // 将标注添加到地图中
            petroChina_marker.addEventListener("click", function () {
                redBoundary();
            });
            petroChina_marker.addEventListener("dblclick", function () {
                blackBoundary();
            });
        });
    }

    getBoundaryCNPC('内江',[104.835, 29.641]);
    getBoundaryCNPC('宜宾',[104.628, 28.691]);
    getBoundaryCNPC('西昌',[102.153, 27.808]);

    //设置中石化区块边界
    function getBoundarySinopec(cityName, iconLocation) {
        var bdary = new BMap.Boundary();
        var name = cityName;
        //var iconPoint = iconLocation;
        bdary.get(name, function (rs) {       //获取行政区域
            var cdPoints = rs.boundaries[0].split(';'); //行政区域的点有多少个
            var overlay = [];
            for (var key in cdPoints) {
                var cdPoint = cdPoints[key].split(',');
                overlay.push(new BMap.Point(cdPoint[0], cdPoint[1]))
            }
            var polygon = new BMap.Polygon(overlay, {
                strokeColor: "black",
                strokeWeight: 1,
                strokeOpacity: 1,
                fillColor: "blue",
                fillOpacity: 0.5
            });  //创建多边形

            //console.log(polygon);
            map.addOverlay(polygon);   //增加多边形
            function redBoundary(){
                polygon.setStrokeWeight(3);
                polygon.setStrokeColor('red');
                polygon.setFillOpacity(0.7);
            }
            function blackBoundary(){
                polygon.setStrokeWeight(1);
                polygon.setStrokeColor('black');
                polygon.setFillOpacity(0.5);
            }

            //鼠标点击，突出边界
            polygon.addEventListener("click", function () {
                redBoundary();
            });
            polygon.addEventListener("dblclick", function () {
                blackBoundary();
            });

            //mouseover左侧列表
            $('.sinopec').on('mouseover', function () {
                polygon.setStrokeWeight(3);
                polygon.setStrokeColor('red');
                polygon.setFillOpacity(0.7);
            });
            $('.sinopec').on('mouseout', function () {
                polygon.setStrokeWeight(1);
                polygon.setStrokeColor('black');
                polygon.setFillOpacity(0.5);
            });

            //在区块上面添加标注
            var sinopec_points = iconLocation;

            var sinopec_pt = new BMap.Point(sinopec_points[0], sinopec_points[1]);
            var sinopec_myIcon = new BMap.Icon("../img/sinopecS02.png", new BMap.Size(23, 20));
            var sinopec_marker = new BMap.Marker(sinopec_pt, {icon: sinopec_myIcon});  // 创建标注
            map.addOverlay(sinopec_marker);              // 将标注添加到地图中
            sinopec_marker.addEventListener("click", function () {
                redBoundary();
            });
            sinopec_marker.addEventListener("dblclick", function () {
                blackBoundary();
            });
        });
    }

    getBoundarySinopec('涪陵',[107.490, 29.681]);
    getBoundarySinopec('永川',[105.964, 29.338]);
    getBoundarySinopec('梁平',[107.872, 30.666]);



    //左边框动画
    $('.leftBarBtn').on('click', function () {
        if ($('.hPContentLeftBarDetails').width() == 0 && $('.hPCompanyName').width() == 0) {

            $('.hPContentLeftBarDetails').animate({width: '15%'}, 'normal');
            $('.hPCompanyName').animate({width: '100%'}, 'normal');
            //$('.secondLevel').show();
        } else {
            $('.hPContentLeftBarDetails').animate({width: '0'}, 'normal');
            $('.hPCompanyName').animate({width: '0'}, 'normal');
            $('.secondLevel').hide();
        }
    });

    //点击展开第二级列表
    $('.sinopec').on('click', function () {
        $('.sinopecItems').slideToggle();
    });
    $('.petroChina').on('click', function () {
        $('.petroChinaItems').slideToggle();
    });
    $('.shellChina').on('click', function () {
        $('.shellChinaItems').slideToggle();
    });

    //点击区块展示区块详情
    $('.sinopec-fulin').on('click',function(){
        $('.block-container').fadeIn('slow');
        $('.hPContentLeftBarDetails').animate({width: '0'}, 'normal');
        $('.hPCompanyName').animate({width: '0'}, 'normal');
        $('.secondLevel').hide();
    });

    //点击首页，回到主界面    //点击返回按钮，回到主页面
    $('.navBtns, .block-container-backToMap').on('click',function(){
        $('.block-container').fadeOut('slow');
    });

});


















